#!/bin/bash

# This is your argument

gpu_device="6"

nproc_per_node=1
master_port=$(shuf -i 10000-45000 -n 1)
echo "Using port $master_port for communication."



data_root=./data
model_root=./checkpoint



MODEL_TYPE='rnalm'

token='3mer'
#token='3splited'
pos='alibi'



model_max_length=1026
seed=666
data=''
MODEL_PATH=${model_root}/baseline/BEACON-B/

task='Secondary_structure_prediction'
batch_size=4
lr=3e-5
DATA_PATH=${data_root}/downstream/${task}/bpRNA
OUTPUT_PATH=./outputs/ft/rna-all/${task}/BEACON-B/${MODEL_TYPE}  
EXEC_PREFIX="env CUDA_VISIBLE_DEVICES=$gpu_device torchrun --nproc_per_node=$nproc_per_node --master_port=$master_port"
echo ${MODEL_PATH}
${EXEC_PREFIX} \
downstream/train_secondary_structure_our.py \
    --model_name_or_path ${MODEL_PATH} \
    --data_path  ${DATA_PATH}/${data} \
    --run_name ${MODEL_TYPE}_${data} \
    --output_dir ${OUTPUT_PATH}/${data} \
    --model_max_length ${model_max_length} \
    --per_device_train_batch_size ${batch_size} \
    --per_device_eval_batch_size 1 \
    --gradient_accumulation_steps 4 \
    --lr ${lr} \
    --num_epochs 100 \
    --patience 60 \
    --num_workers 1 \
    --token_type ${token} \
    --model_type ${MODEL_TYPE} \
    --seed ${seed} \
    --pretrained_path '/path/to/your/pretrained_model_checkpoint' 