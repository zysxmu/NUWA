#!/bin/bash

# This is your argument

gpu_device="7"

nproc_per_node=1
master_port=$(shuf -i 10000-45000 -n 1)
echo "Using port $master_port for communication."



data_root=./data
model_root=./checkpoint



MODEL_TYPE='rnalm'

token='3mer'
#token='3splited'
pos='alibi'



model_max_length=1026
seed=666
data=''
MODEL_PATH=${model_root}/baseline/BEACON-B/



task='MeanRibosomeLoading'
data_file_train=train.csv; data_file_val=val.csv; data_file_test=test.csv
#batch_size=32
batch_size=128
# lr=1e-5
lr=5e-5
DATA_PATH=${data_root}/downstream/${task}
OUTPUT_PATH=./outputs/ft/rna-all/${task}/BEACON-B/${MODEL_TYPE}
EXEC_PREFIX="env CUDA_VISIBLE_DEVICES=$gpu_device torchrun --nproc_per_node=$nproc_per_node --master_port=$master_port"
echo ${MODEL_PATH}
${EXEC_PREFIX} \
downstream/train_mean_ribosome_loading_our.py \
    --model_name_or_path $MODEL_PATH \
    --data_path  $DATA_PATH/$data \
    --data_train_path ${data_file_train} --data_val_path ${data_file_val} --data_test_path ${data_file_test}   \
    --run_name ${MODEL_TYPE}_${data} \
    --model_max_length 1026 \
    --per_device_train_batch_size $batch_size \
    --per_device_eval_batch_size 32 \
    --gradient_accumulation_steps 1 \
    --learning_rate ${lr} \
    --num_train_epochs 30 \
    --fp16 \
    --save_steps 400 \
    --output_dir ${OUTPUT_PATH}/${seed} \
    --eval_strategy steps \
    --eval_steps 200 \
    --warmup_steps 50 \
    --logging_steps 200 \
    --overwrite_output_dir True \
    --log_level info \
    --seed ${seed} \
    --token_type ${token} \
    --model_type ${MODEL_TYPE} \
    --pretrained_path '/path/to/your/pretrained_model_checkpoint' 

