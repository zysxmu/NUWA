# NUWA-Agent Reviewer Summary

> This is the authoritative concise report. Raw LLM proposals are preserved in the > companion `nuwa_agent_chain_20260924_004659.md` audit appendix and are not executable decisions.

## Run identity

- Run ID: `20260924_004659`
- Created: `2026-09-24T00:47:57.006589+08:00`
- Audit schema: `2.0`
- Host: `Homo sapiens`
- Protein length: `201 aa`
- Protein SHA256: `4342b6489807d6b0dff080298e9ecb6adbce07d523e99157de4aebd6a3954e17`
- Run seed: `42`
- Source-tree SHA256: `3f1aeb9fc7b87ac42801ff49b1f640c89b84d3cb24e6f4916b61ca1b340daf43`
- LLM model: `GLM-5.1`
- Strict evaluation: `True`
- Artifact self-validation: `True`
- Validation checks: `active_constraints, best_round_solution_provenance, canonical_sequences, decision_timeline_consistency, input_protein_sha256, model_artifact_sha256, pareto_feasibility, run_seed_recorded, species_class_id_consistency`

## Exact input protein

```text
MGSNSFSTSAFGPVAFSLGLLLVLPAAFPAPVFTLEDFVGDWRQTAGYNLDQVLEQGGVSSLFQNLGVSVTPIQRIVLSGENGLKIDIHVIIPYEGLSGDQMGQIEKIFKVVYPVDDHHFKVILHYGTLVIDGVTPNMIDYFGRPYEGIAVFDGKKITVTGTLWNGNKIIDERLINPDGSLLFRVTINGVTGWRLCERILA
```

## Model and species selection

- NUWA model: `NUWA-Eukaryote`
- Final species/proxy: `Homo sapiens`
- Final class ID: `2122`
- Resolution type: `exact`
- Resolver initial suggestion: `Homo sapiens` / class_id=`2122`

## Effective constraints

- MFE mode: `per_nt`
- Active bounds: `{"cai_min": 0.7, "gc_max": 0.75, "gc_min": 0.3, "max_homopolymer": 6, "max_stem_length": 33, "mfe_per_nt_max": -0.32, "mfe_per_nt_min": -0.52}`
- Inactive legacy bounds: `{"mfe_max": -100, "mfe_min": -400}`

## Optimization result

- Total rounds: `10`
- Converged: `False`
- Best round: `8`
- Best HV (returned set): `0.44505753174472135`
- Last-round HV: `0.44495366102271416`

| Round | HV | Delta HV | Feasible | Pareto front | Applied decision source |
|---:|---:|---:|---:|---:|---|
| 1 | 0.229800 | +0.229800 | 15/50 | 3 | preregistered_round_1_baseline |
| 2 | 0.240240 | +0.010440 | 30/50 | 4 | previous_round_guardrail_adjusted_decision |
| 3 | 0.238888 | -0.001352 | 37/50 | 7 | previous_round_guardrail_adjusted_decision |
| 4 | 0.239066 | +0.000178 | 39/50 | 5 | previous_round_guardrail_adjusted_decision |
| 5 | 0.269671 | +0.030605 | 33/50 | 17 | previous_round_guardrail_adjusted_decision |
| 6 | 0.320874 | +0.051203 | 34/50 | 4 | previous_round_guardrail_adjusted_decision |
| 7 | 0.441862 | +0.120989 | 44/50 | 2 | previous_round_guardrail_adjusted_decision |
| 8 | 0.445058 | +0.003195 | 34/50 | 2 | previous_round_guardrail_adjusted_decision |
| 9 | 0.433422 | -0.011636 | 34/50 | 2 | previous_round_guardrail_adjusted_decision |
| 10 | 0.444954 | +0.011532 | 40/50 | 3 | previous_round_guardrail_adjusted_decision |

## Model artifact manifests

| Purpose | Checkpoint | Content-addressed manifest SHA256 | Exists |
|---|---|---|---|
| generation | checkpoint-1153028 | `5da754eb229d1c636fc399896bf92df526709291f6067f56d75b54260d27c79c` | True |
| te | checkpoint-1000 | `592e102731fc38374626447e4a97474a3537f3b95f2fe0ee152d32b5e3dab791` | True |
| stability | checkpoint-1000 | `cb4e2df1352055c3d67d27f5c3f51b19e1ec1bb550914f67877b7ccb7255d223` | True |
| expression | checkpoint-1000 | `227d619ff7d650bdc2e0244a733ffa27336d3a65988770b0d5e1d16219b1161c` | True |

## Returned Pareto solutions

Canonical `sequence` values are uppercase, unspaced RNA. The codon-spaced form is display-only.

| ID | Rank | TE | Stability | Expression | CAI | GC | MFE/nt | Stem | Homopolymer | nt | Feasible |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| S001 | 0 | 0.768324 | 0.818180 | 0.568643 | 0.901294 | 0.610561 | -0.364026 | 9 | 5 | 606 | True |
| S002 | 0 | 0.765179 | 0.841942 | 0.688558 | 0.845384 | 0.608911 | -0.392574 | 13 | 4 | 606 | True |

## Canonical sequences

### S001

```text
AUGGGCUCUAACUCCUUCAGCACCUCUGCUUUCGGUCCCGUGGCCUUCUCCCUGGGUCUGCUGCUGGUGCUGCCUGCCGCAUUCCCCGCUCCCGUGUUCACCCUGGAGGACUUCGUGGGCGACUGGCGUCAGACCGCCGGCUACAACCUGGACCAGGUGCUGGAGCAAGGCGGCGUGUCCUCCCUGUUCCAGAACCUGGGUGUGAGCGUGACCCCUAUCCAGCGCAUCGUGCUGUCCGGUGAGAACGGUCUGAAGAUCGACAUCCACGUCAUCAUCCCUUACGAGGGCCUGUCUGGUGACCAGAUGGGUCAGAUCGAGAAGAUCUUCAAGGUGGUGUACCCUGUGGACGACCACCACUUCAAGGUGAUCCUGCACUACGGUACCCUGGUGAUCGACGGCGUGACCCCCAACAUGAUCGACUACUUCGGCCGUCCCUACGAGGGCAUCGCUGUGUUCGACGGCAAGAAGAUCACCGUGACGGGCACCCUGUGGAACGGCAACAAGAUCAUCGACGAGCGCCUCAUCAACCCCGACGGCUCCCUCCUCUUCCGCGUGACCAUCAACGGUGUGACCGGCUGGCGUCUGUGUGAGCGUAUCCUGGCCUAG
```

### S002

```text
AUGGGCUCCAACUCCUUCUCCACCUCCGCCUUCGGCCCCGUGGCUUUCUCCCUGGGCCUCCUCCUGGUGCUGCCCGCUGCCUUCCCCGCUCCCGUGUUCACCCUGGAGGACUUCGUGGGUGACUGGCGUCAGACCGCUGGUUACAACCUCGACCAGGUGCUGGAGCAGGGCGGUGUGUCCUCGCUGUUCCAGAACCUGGGUGUGUCUGUCACGCCCAUCCAGCGCAUCGUGCUGUCGGGUGAGAACGGUCUGAAGAUCGACAUCCACGUGAUCAUCCCCUACGAGGGUCUGUCUGGCGACCAGAUGGGCCAGAUCGAGAAGAUCUUCAAGGUCGUCUACCCCGUGGACGACCACCACUUCAAGGUCAUCCUCCACUACGGUACCCUGGUCAUCGACGGUGUGACGCCCAACAUGAUCGACUACUUCGGUCGUCCCUAUGAGGGUAUCGCUGUCUUCGACGGUAAGAAGAUCACCGUGACCGGUACCCUGUGGAACGGUAACAAGAUCAUCGACGAGCGCCUGAUCAACCCCGACGGCUCCCUCCUGUUCCGCGUCACCAUCAACGGUGUCACUGGCUGGCGCCUCUGCGAGCGCAUCCUGGCCUAA
```

## Reproducibility note

The seed controls local Python/NumPy/PyTorch stochastic operations. Remote LLM and some accelerator kernels may still be nondeterministic; complete prompts and responses are retained in the audit log.

Machine-readable record: `nuwa_agent_20260924_004659.json`.